package ex1;

public class Flag {
	public static void main(String[] args) {
		White white = new White();
		Blue blue = new Blue();
		
		white.start();
		blue.start();
	}
}
